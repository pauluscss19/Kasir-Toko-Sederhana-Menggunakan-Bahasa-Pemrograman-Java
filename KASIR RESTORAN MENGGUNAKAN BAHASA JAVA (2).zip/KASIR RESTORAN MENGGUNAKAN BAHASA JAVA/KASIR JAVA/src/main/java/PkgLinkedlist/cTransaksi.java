package PkgLinkedlist;
public class cTransaksi {
    String kode;
    String barang;
    String pembeli;
    cBarang Barang;
    int jumlahBrg;
    int status;
    cTransaksi next;
    cTransaksi (String k, String p, cBarang b, int j, int s){
        kode=k; pembeli=p; Barang=b; jumlahBrg=j; status=s;
        next=null;
    }
    public void setStatus(int s){
        status=s;
    }
    public String getKode(){
        return kode;
    }
    public String getPembeli(){
        return pembeli;
    }
    public cBarang getBarang(){
        return Barang;
    }
    public int getJumlah(){
        return jumlahBrg;
    }
    public int getStatus(){
        return status;
    }
}
